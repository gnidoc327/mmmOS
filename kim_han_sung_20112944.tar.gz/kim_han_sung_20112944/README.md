Machine Problem 2 : Synchronization and Threads in User Space

Team name : Manner Maketh Man

---------------------------------------------------------------

Member : kim han sung(20112944), kim seong won(20112618)

Environment - ubuntu 14.04 LTS

Executable, Special compiling instructions or Anything 
