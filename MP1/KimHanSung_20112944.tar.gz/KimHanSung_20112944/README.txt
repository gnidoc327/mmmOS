Machine Problem 1 : Building a shell

Time name : Manner Maketh Man

Member : kim han sung(20112944), kim seong won(20112618)

--------------------------------------------------------

Submission Instructions


1. Executable Instructions

cd, jobs, exit


2. Special Instructions

help

3. Anything else



